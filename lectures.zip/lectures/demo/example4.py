#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 01:29:49 2018

@author: hangjieji
"""

import example3

print "example4 is runnning"
print "its __name__ is ",__name__
example3.main()