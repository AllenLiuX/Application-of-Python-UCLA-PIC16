#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 12 12:34:32 2019

@author: hangjieji
"""

import myFunctions as mf
#print f1(1) # this won't work since "f1" is not in the current symbol table yet

print mf.f1(1)
print mf.myDictionary